/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"jetCourses/ControlTask_Sirosh/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"jetCourses/ControlTask_Sirosh/test/integration/pages/Worklist",
	"jetCourses/ControlTask_Sirosh/test/integration/pages/Object",
	"jetCourses/ControlTask_Sirosh/test/integration/pages/NotFound",
	"jetCourses/ControlTask_Sirosh/test/integration/pages/Browser",
	"jetCourses/ControlTask_Sirosh/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "jetCourses.ControlTask_Sirosh.view."
	});

	sap.ui.require([
		"jetCourses/ControlTask_Sirosh/test/integration/WorklistJourney",
		"jetCourses/ControlTask_Sirosh/test/integration/ObjectJourney",
		"jetCourses/ControlTask_Sirosh/test/integration/NavigationJourney",
		"jetCourses/ControlTask_Sirosh/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});